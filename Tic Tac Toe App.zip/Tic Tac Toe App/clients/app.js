var app = angular.module("ticTacToeApp", []);

app.controller("GameController", function($scope, $http) {

$scope.board = ["","","","","","","","",""];
$scope.currentPlayer = "X";
$scope.winner = null;
$scope.history = [];

$scope.winningCombos = [
[0,1,2],[3,4,5],[6,7,8],
[0,3,6],[1,4,7],[2,5,8],
[0,4,8],[2,4,6]
];

$scope.makeMove = function(index){

if($scope.board[index] || $scope.winner) return;

$scope.board[index] = $scope.currentPlayer;

if(checkWinner()){
$scope.winner = $scope.currentPlayer;
saveGame();
}else{
$scope.currentPlayer = $scope.currentPlayer === "X" ? "O" : "X";
}

};

function checkWinner(){

for(let combo of $scope.winningCombos){

let [a,b,c] = combo;

if(
$scope.board[a] &&
$scope.board[a] === $scope.board[b] &&
$scope.board[a] === $scope.board[c]
){
return true;
}

}

return false;

}

function saveGame(){

$http.post("http://localhost:5000/api/games",{
board: $scope.board,
winner: $scope.winner
});

loadHistory();

}

$scope.resetGame = function(){

$scope.board = ["","","","","","","","",""];
$scope.winner = null;
$scope.currentPlayer = "X";

};

function loadHistory(){

$http.get("http://localhost:5000/api/games")
.then(function(res){
$scope.history = res.data;
});

}

loadHistory();

});