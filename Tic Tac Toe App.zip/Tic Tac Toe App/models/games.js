const mongoose = require("mongoose");

const GameSchema = new mongoose.Schema({
    board: [String],
    winner: String,
    date: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model("games", GameSchema);