const express = require("express");
const router = express.Router();
const Game = require("../models/games");

router.post("/", async (req, res) => {
    try {
        const game = new Game(req.body);
        const savedGame = await game.save();
        res.json(savedGame);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.get("/", async (req, res) => {
    const games = await Game.find().sort({ date: -1 });
    res.json(games);
});

module.exports = router;