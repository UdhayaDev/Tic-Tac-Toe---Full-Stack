const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");

const gameRoutes = require("./routes/gameroutes");

const app = express();

app.use(cors());
app.use(bodyParser.json());

mongoose.connect("mongodb://127.0.0.1:27017/tictactoe")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

app.use("/api/games", gameRoutes);

const PORT = 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});